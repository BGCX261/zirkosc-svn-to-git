
#ifndef __ZirkOSCAU_h__
#define __ZirkOSCAU_h__

#include "AUEffectBase.h"
#include "AudioToolbox/AudioUnitUtilities.h"

#include "ZirkOSCVersion.h"
#include "ZirkConstants.h"

#include "lo/lo.h"
#include <string>

#if AU_DEBUG_DISPATCHER
# include "AUDebugDispatcher.h"
#endif

#pragma mark ____ZirkOSCAU Parameters

typedef struct PolarAngles
{
    Float32     azimuth;
    Float32     zenith;
} PolarAngles;

#pragma mark ____ZirkOSCAU
class ZirkOSCAU : public AUEffectBase
{
public:
    
    ZirkOSCAU(AudioUnit component);
	virtual ~ZirkOSCAU ();
	
	
	virtual void SetBypassEffect (bool inFlag)
	{
		printf("SetBypassEffect: %d\n", inFlag);
		AUEffectBase::SetBypassEffect(inFlag);
	}
	
	
	virtual AUKernelBase *		NewKernel() { return new ZirkOSCAUKernel(this); }
	
	virtual UInt32				SupportedNumChannels (	const AUChannelInfo** 			outInfo);
	
	virtual	OSStatus			GetParameterValueStrings(AudioUnitScope			inScope,
														 AudioUnitParameterID		inParameterID,
														 CFArrayRef *			outStrings);
    
	virtual	OSStatus			GetParameterInfo(AudioUnitScope			inScope,
												 AudioUnitParameterID	inParameterID,
												 AudioUnitParameterInfo	&outParameterInfo);
    
	virtual OSStatus			GetPropertyInfo(AudioUnitPropertyID		inID,
												AudioUnitScope			inScope,
												AudioUnitElement		inElement,
												UInt32 &			outDataSize,
												Boolean	&			outWritable );
	
	virtual OSStatus			GetProperty(AudioUnitPropertyID inID,
											AudioUnitScope 		inScope,
											AudioUnitElement 		inElement,
											void *			outData);
											
	virtual OSStatus			SetProperty(AudioUnitPropertyID inID,
									   AudioUnitScope 		inScope,
									   AudioUnitElement 	inElement,
									   const void *			inData,
									   UInt32 				inDataSize);
	
	virtual OSStatus			SetParameter(AudioUnitParameterID inID,
												AudioUnitScope inScope,
												AudioUnitElement inElement,
												AudioUnitParameterValue inValue,
												UInt32 inBufferOffsetInFrames);
	
	
	/*! @method Version */
	virtual OSStatus			Version() { return kZirkOSCAUVersion; }
	
	virtual OSStatus			SaveState( CFPropertyListRef * outData);
	virtual OSStatus			RestoreState( CFPropertyListRef inData);
	
	void updateOscPort();
	
	lo_address mOsc;
	uint32_t mChannel;
	uint32_t mChannelCount;
	uint32_t mOscPort;
	uint32_t mActive;
	
protected:
		class ZirkOSCAUKernel : public AUKernelBase		// most real work happens here
	{
public:
		ZirkOSCAUKernel(AUEffectBase *inAudioUnit );
		//:AUKernelBase(inAudioUnit);
	//{
	//}
		
		// *Required* overides for the process method for this effect
		// processes one channel of interleaved samples
        virtual void 		Process(	const Float32 	*inSourceP,
										Float32		 	*inDestP,
										UInt32 			inFramesToProcess,
										UInt32			inNumChannels,
										bool			&ioSilence);
		
        virtual void		Reset();
		
private:
        //state variables...
    };
};

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


#endif /* __ZirkOSCAU_h__ */
