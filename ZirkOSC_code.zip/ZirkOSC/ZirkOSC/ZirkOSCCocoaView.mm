/*
*	File:		ZirkOSCCocoaView.m
*	
*	Version:	1.0
* 
*	Created:	9/20/11
*	
*	Copyright:  Copyright 2011 __MyCompanyName__. All rights reserved.
* 
*	Disclaimer:	IMPORTANT:  This Apple software is supplied to you by Apple Computer, Inc. ("Apple") in 
*				consideration of your agreement to the following terms, and your use, installation, modification 
*				or redistribution of this Apple software constitutes acceptance of these terms.  If you do 
*				not agree with these terms, please do not use, install, modify or redistribute this Apple 
*				software.
*
*				In consideration of your agreement to abide by the following terms, and subject to these terms, 
*				Apple grants you a personal, non-exclusive license, under Apple's Copyrights in this 
*				original Apple software (the "Apple Software"), to use, reproduce, modify and redistribute the 
*				Apple Software, with or without modifications, in source and/or binary forms; provided that if you 
*				redistribute the Apple Software in its entirety and without modifications, you must retain this 
*				notice and the following text and disclaimers in all such redistributions of the Apple Software. 
*				Neither the name, trademarks, service marks or logos of Apple Computer, Inc. may be used to 
*				endorse or promote products derived from the Apple Software without specific prior written 
*				permission from Apple.  Except as expressly stated in this notice, no other rights or 
*				licenses, express or implied, are granted by Apple herein, including but not limited to any 
*				patent rights that may be infringed by your derivative works or by other works in which the 
*				Apple Software may be incorporated.
*
*				The Apple Software is provided by Apple on an "AS IS" basis.  APPLE MAKES NO WARRANTIES, EXPRESS OR 
*				IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY 
*				AND FITNESS FOR A PARTICULAR PURPOSE, REGARDING THE APPLE SOFTWARE OR ITS USE AND OPERATION ALONE 
*				OR IN COMBINATION WITH YOUR PRODUCTS.
*
*				IN NO EVENT SHALL APPLE BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR CONSEQUENTIAL 
*				DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS 
*				OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) ARISING IN ANY WAY OUT OF THE USE, 
*				REPRODUCTION, MODIFICATION AND/OR DISTRIBUTION OF THE APPLE SOFTWARE, HOWEVER CAUSED AND WHETHER 
*				UNDER THEORY OF CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, EVEN 
*				IF APPLE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
*/

#import "ZirkOSCCocoaView.h"
#import "ZirkConstants.h"

#pragma mark - Listener Callback Dispatcher

void ParameterListenerDispatcher (void *inRefCon, void *inObject, const AudioUnitParameter *inParameter, Float32 inValue)
{
	ZirkOSCCocoaView *SELF = (ZirkOSCCocoaView *)inRefCon;
    [SELF priv_parameterListener:inObject parameter:inParameter value:inValue];
}
 
// This listener responds to parameter changes, gestures, and property notifications
void EventListenerDispatcher (void *inRefCon, void *inObject, const AudioUnitEvent *inEvent, UInt64 inHostTime, Float32 inValue)
{
	ZirkOSCCocoaView *SELF = (ZirkOSCCocoaView *)inRefCon;
    //printf(SELF);
    if (SELF != NULL) {
        [SELF priv_eventListener:inObject event:inEvent value:inValue];
    }
}

NSString *ZirkOSCAU_GestureSliderMouseDownNotification = @"CAGestureSliderMouseDownNotification";
NSString *ZirkOSCAU_GestureSliderMouseUpNotification = @"CAGestureSliderMouseUpNotification";

@implementation ZirkOSCAU_GestureSlider
// NSSlider starts a second run loop in mouseDown: we don't want that as it breaks
// automation writing in Digital performer
- (void)mouseDown:(NSEvent*)theEvent
{
	mThickness = [[self cell] knobThickness];
	[[NSNotificationCenter defaultCenter] postNotificationName: ZirkOSCAU_GestureSliderMouseDownNotification object: self];
	[self mouseDragged:theEvent];
}
- (void)mouseDragged:(NSEvent *)theEvent
{
	NSPoint p = [self convertPoint:[theEvent locationInWindow] fromView:nil];
	NSRect b = [self bounds];
	b.origin.x += mThickness / 2;
	b.size.width -= mThickness;
	double min = [self minValue];
	double max = [self maxValue];
	double x = (p.x - b.origin.x) / b.size.width;
	[self setDoubleValue:min + x * (max - min)];
	
	id t = [self target];
	SEL a = [self action];
	if (t && a) [t performSelector:a withObject:self];
}
- (void)mouseUp:(NSEvent *)theEvent
{
	[self mouseDragged:theEvent];
	[[NSNotificationCenter defaultCenter] postNotificationName: ZirkOSCAU_GestureSliderMouseUpNotification object: self];
}
@end

@implementation ZirkOSCCocoaView

- (void)dealloc
{
    printf("dealloc\n");
    [self priv_removeListeners];
    [super dealloc];
}

- (BOOL) acceptsFirstResponder
{
	return YES;
}

#pragma mark - Public Functions

- (void)setAU:(AudioUnit)inAU
{
	// remove previous listeners
	if (mAU) [self priv_removeListeners];
	mAU = inAU;
    
	// Dome view observers
	[[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(onDataChanged:) name: kDomeViewDataChangedNotification object: domeView];
	[[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(onBeginGesture:) name: kDomeViewBeginGestureNotification object: domeView];
	[[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(onEndGesture:) name: kDomeViewEndGestureNotification object: domeView];
	
    [[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(channelChanged:) name: NSControlTextDidChangeNotification object: channelField];
    [[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(channelCountChanged:) name: NSControlTextDidChangeNotification object: channelCountField];
	[[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(portChanged:) name: NSControlTextDidChangeNotification object: oscPortField];
    
	
    // Manual controls:
	for (int i = 0; i < kNumberOfParameters; i++)
	{
		mParameter[i].mAudioUnit = inAU;
		mParameter[i].mParameterID = (AudioUnitParameterID)i;
		mParameter[i].mScope = kAudioUnitScope_Global;
		mParameter[i].mElement = 0;	
	}

	// add new listeners
	[self priv_addListeners];
	
	// initial setup
	[self priv_synchronizeUIWithParameterValues];
	
	{
		UInt32 size = sizeof(uint32_t);
		uint32_t channel;
		AudioUnitGetProperty(inAU, kChannelId, kAudioUnitScope_Global, 0, &channel, &size);
		[channelField setStringValue:[NSString stringWithFormat:@"%d", channel + 1]];
	}
	{
		UInt32 size = sizeof(uint32_t);
		uint32_t channel;
		AudioUnitGetProperty(inAU, kChannelCountId, kAudioUnitScope_Global, 0, &channel, &size);
		[channelCountField setStringValue:[NSString stringWithFormat:@"%d", channel]];
		[domeView setChannelCount:channel];
		[domeView setNeedsDisplay:YES];
	}
	{
		UInt32 size = sizeof(uint32_t);
		uint32_t port;
		AudioUnitGetProperty(inAU, kOscPortId, kAudioUnitScope_Global, 0, &port, &size);
		[oscPortField setStringValue:[NSString stringWithFormat:@"%d", port]];
	}
	{
		UInt32 size = sizeof(uint32_t);
		uint32_t active;
		AudioUnitGetProperty(inAU, kOscActiveId, kAudioUnitScope_Global, 0, &active, &size);
		[activeButton setState:active ? NSOnState : NSOffState];
	}
}

- (AudioUnit)getAU
{
	return mAU;
}

#pragma mark - Interface Actions
- (void)channelChanged:(NSNotification *) aNotification
{
	int c = [channelField intValue];
	if (c < 1) c = 1;
	
	NSString *s = [NSString stringWithFormat:@"%d", c];
	if (![s isEqual:[channelField stringValue]])
		[channelField setStringValue:s];
	
	uint32_t channel = c - 1;
	AudioUnitSetProperty(mAU, kChannelId, kAudioUnitScope_Global, 0, &channel, sizeof(uint32_t));	
}

- (void)channelCountChanged:(NSNotification *) aNotification
{
	int c = [channelCountField intValue];
	if (c < 1) c = 1;
	
	NSString *s = [NSString stringWithFormat:@"%d", c];
	if (![s isEqual:[channelCountField stringValue]])
		[channelCountField setStringValue:s];
	
	uint32_t channel = c;
	AudioUnitSetProperty(mAU, kChannelCountId, kAudioUnitScope_Global, 0, &channel, sizeof(uint32_t));	
	
	[domeView setChannelCount:channel];
	[domeView setNeedsDisplay:YES];
}

- (void)portChanged:(NSNotification *) aNotification
{
	int c = [oscPortField intValue];
	if (c < 1) c = 1;
	else if (c > 65535) c = 65535;
	
	NSString *s = [NSString stringWithFormat:@"%d", c];
	if (![s isEqual:[oscPortField stringValue]])
		[oscPortField setStringValue:s];
	
	uint32_t port = c;
	AudioUnitSetProperty(mAU, kOscPortId, kAudioUnitScope_Global, 0, &port, sizeof(uint32_t));	
}

- (void) parameterChanged:(AudioUnitParameterID)paramId
{
	AudioUnitEvent event;
	AudioUnitParameter parameter = { mAU, paramId, kAudioUnitScope_Global, 0 };
	event.mArgument.mParameter = parameter;
	event.mEventType = kAudioUnitEvent_ParameterValueChange;
	AUEventListenerNotify (mEventListener, self, &event);
}

- (IBAction)azimChanged:(id)sender {
    float floatValue = [sender floatValue];
	NSAssert(AUParameterSet(mParameterListener, sender, &mParameter[kZirkOSC_Azim], (Float32)floatValue, 0) == noErr, @"[spatosc_CocoaView azimChanged:] AUParameterSet()");
    [self parameterChanged:kZirkOSC_Azim];
	if (sender == azimSlider) {
        [azimField setFloatValue:floatValue];
    } else {
        [azimSlider setFloatValue:floatValue];
    }
	[domeView setAzimuth: floatValue];
	[domeView setNeedsDisplay:YES];
}

- (IBAction)elevChanged:(id)sender {
    float floatValue = [sender floatValue];
	NSAssert(AUParameterSet(mParameterListener, sender, &mParameter[kZirkOSC_Elev], (Float32)floatValue, 0) == noErr, @"[spatosc_CocoaView elevChanged:] AUParameterSet()");
    [self parameterChanged:kZirkOSC_Elev];
	if (sender == elevSlider) {
        [elevField setFloatValue:floatValue];
    } else {
        [elevSlider setFloatValue:floatValue];
	}
	[domeView setZenith: floatValue];
	[domeView setNeedsDisplay:YES];
}
- (IBAction)azimDeltaChanged:(id)sender
{
    float floatValue = [sender floatValue];
	NSAssert(AUParameterSet(mParameterListener, sender, &mParameter[kZirkOSC_AzimDelta], (Float32)floatValue, 0) == noErr, @"[spatosc_CocoaView azimDeltaChanged:] AUParameterSet()");
    [self parameterChanged:kZirkOSC_AzimDelta];
	if (sender == azimDeltaSlider) {
        [azimDeltaField setFloatValue:floatValue];
    } else {
        [azimDeltaSlider setFloatValue:floatValue];
    }
	[domeView setAzimuthDelta: floatValue];
	[domeView setNeedsDisplay:YES];
}
- (IBAction)elevDeltaChanged:(id)sender
{
	float floatValue = [sender floatValue];
	NSAssert(AUParameterSet(mParameterListener, sender, &mParameter[kZirkOSC_ElevDelta], (Float32)floatValue, 0) == noErr, @"[spatosc_CocoaView elevDeltaChanged:] AUParameterSet()");
    [self parameterChanged:kZirkOSC_ElevDelta];
	if (sender == elevDeltaSlider) {
        [elevDeltaField setFloatValue:floatValue];
    } else {
        [elevDeltaSlider setFloatValue:floatValue];
	}
	[domeView setZenithDelta: floatValue];
	[domeView setNeedsDisplay:YES];
}

- (IBAction)azimSpanChanged:(id)sender
{
    float floatValue = [sender floatValue];
	NSAssert(AUParameterSet(mParameterListener, sender, &mParameter[kZirkOSC_AzimSpan], (Float32)floatValue, 0) == noErr, @"[spatosc_CocoaView azimSpanChanged:] AUParameterSet()");
    [self parameterChanged:kZirkOSC_AzimSpan];
	if (sender == azimSpanSlider) {
        [azimSpanField setFloatValue:floatValue];
    } else {
        [azimSpanSlider setFloatValue:floatValue];
    }
	[domeView setAzimuthSpan: floatValue];
	[domeView setNeedsDisplay:YES];
}
- (IBAction)elevSpanChanged:(id)sender
{
	float floatValue = [sender floatValue];
	NSAssert(AUParameterSet(mParameterListener, sender, &mParameter[kZirkOSC_ElevSpan], (Float32)floatValue, 0) == noErr, @"[spatosc_CocoaView elevSpanChanged:] AUParameterSet()");
    [self parameterChanged:kZirkOSC_ElevSpan];
	if (sender == elevSpanSlider) {
        [elevSpanField setFloatValue:floatValue];
    } else {
        [elevSpanSlider setFloatValue:floatValue];
	}
	[domeView setZenithSpan: floatValue];
	[domeView setNeedsDisplay:YES];
}
- (IBAction)gainChanged:(id)sender
{
	float floatValue = [sender floatValue];
	NSAssert(AUParameterSet(mParameterListener, sender, &mParameter[kZirkOSC_Gain], (Float32)floatValue, 0) == noErr, @"[spatosc_CocoaView gainChanged:] AUParameterSet()");
    [self parameterChanged:kZirkOSC_Gain];
	if (sender == gainSlider) {
        [gainField setFloatValue:floatValue];
    } else {
        [gainSlider setFloatValue:floatValue];
	}
}
- (IBAction)activeChanged:(id)sender
{
	uint32_t active = ([activeButton state] == NSOnState) ? 1 : 0;
	AudioUnitSetProperty(mAU, kOscActiveId, kAudioUnitScope_Global, 0, &active, sizeof(uint32_t));		
}

#pragma mark - Dome View Actions

- (void)onDataChanged:(NSNotification *) aNotification
{
    AudioUnitParameter azimParameter = { mAU, kZirkOSC_Azim, kAudioUnitScope_Global, 0 };
    AudioUnitParameter elevParameter = { mAU, kZirkOSC_Elev,  kAudioUnitScope_Global, 0 };
	
	NSAssert(AUParameterSet(mEventListener, azimField, &azimParameter, (Float32)domeView.azimuth, 0) == noErr, @"[spatosc_CocoaView azimChanged:] AUParameterSet()");
	NSAssert(AUParameterSet(mEventListener, elevField, &elevParameter, (Float32)domeView.zenith, 0) == noErr, @"[spatosc_CocoaView elevChanged:] AUParameterSet()");

	AudioUnitEvent event;
	AudioUnitParameter parameter = { mAU, kZirkOSC_Azim, kAudioUnitScope_Global, 0 };
	event.mArgument.mParameter = parameter;
	event.mEventType = kAudioUnitEvent_ParameterValueChange;
	AUEventListenerNotify (mEventListener, self, &event);
	
	event.mArgument.mParameter.mParameterID = kZirkOSC_Elev;
	AUEventListenerNotify (mEventListener, self, &event);
}

- (void)onBeginGesture:(NSNotification *) aNotification 
{
	AudioUnitEvent event;
	AudioUnitParameter parameter = { mAU, kZirkOSC_Azim, kAudioUnitScope_Global, 0 };
	event.mArgument.mParameter = parameter;
	event.mEventType = kAudioUnitEvent_BeginParameterChangeGesture;
	
	AUEventListenerNotify (mEventListener, self, &event);
	
	event.mArgument.mParameter.mParameterID = kZirkOSC_Elev;
	AUEventListenerNotify (mEventListener, self, &event);
}

- (void)onEndGesture:(NSNotification *) aNotification
{
	AudioUnitEvent event;
	AudioUnitParameter parameter = {mAU, kZirkOSC_Azim, kAudioUnitScope_Global, 0 };
	event.mArgument.mParameter = parameter;
	event.mEventType = kAudioUnitEvent_EndParameterChangeGesture;
	
	AUEventListenerNotify (mEventListener, self, &event);
	
	event.mArgument.mParameter.mParameterID = kZirkOSC_Elev;
	AUEventListenerNotify (mEventListener, self, &event);	
}

#pragma mark - Notifications

// This routine is called when the user has clicked on the slider. We need to send a begin parameter change gesture to alert hosts that the parameter may be changing value
-(void)handleMouseDown: (NSNotification *) aNotification {
	if ([aNotification object] == azimSlider) {
		AudioUnitEvent event;
		event.mArgument.mParameter = mParameter[kZirkOSC_Azim];
		event.mEventType = kAudioUnitEvent_BeginParameterChangeGesture;
		
		AUEventListenerNotify (NULL, self, &event);		// NOTE, if you have an AUEventListenerRef because you are listening to event notification, 
		// pass that as the first argument to AUEventListenerNotify instead of NULL 
	}
	else if ([aNotification object] == elevSlider) {
		AudioUnitEvent event;
		event.mArgument.mParameter = mParameter[kZirkOSC_Elev];
		event.mEventType = kAudioUnitEvent_BeginParameterChangeGesture;
		
		AUEventListenerNotify (NULL, self, &event);		// NOTE, if you have an AUEventListenerRef because you are listening to event notification, 
		// pass that as the first argument to AUEventListenerNotify instead of NULL 
	}
	else if ([aNotification object] == azimDeltaSlider) {
		AudioUnitEvent event;
		event.mArgument.mParameter = mParameter[kZirkOSC_AzimDelta];
		event.mEventType = kAudioUnitEvent_BeginParameterChangeGesture;
		
		AUEventListenerNotify (NULL, self, &event);		// NOTE, if you have an AUEventListenerRef because you are listening to event notification, 
		// pass that as the first argument to AUEventListenerNotify instead of NULL 
	}
	else if ([aNotification object] == elevDeltaSlider) {
		AudioUnitEvent event;
		event.mArgument.mParameter = mParameter[kZirkOSC_ElevDelta];
		event.mEventType = kAudioUnitEvent_BeginParameterChangeGesture;
		
		AUEventListenerNotify (NULL, self, &event);		// NOTE, if you have an AUEventListenerRef because you are listening to event notification, 
		// pass that as the first argument to AUEventListenerNotify instead of NULL 
	}
	else if ([aNotification object] == azimSpanSlider) {
		AudioUnitEvent event;
		event.mArgument.mParameter = mParameter[kZirkOSC_AzimSpan];
		event.mEventType = kAudioUnitEvent_BeginParameterChangeGesture;
		
		AUEventListenerNotify (NULL, self, &event);		// NOTE, if you have an AUEventListenerRef because you are listening to event notification, 
		// pass that as the first argument to AUEventListenerNotify instead of NULL 
	}
	else if ([aNotification object] == elevSpanSlider) {
		AudioUnitEvent event;
		event.mArgument.mParameter = mParameter[kZirkOSC_ElevSpan];
		event.mEventType = kAudioUnitEvent_BeginParameterChangeGesture;
		
		AUEventListenerNotify (NULL, self, &event);		// NOTE, if you have an AUEventListenerRef because you are listening to event notification, 
		// pass that as the first argument to AUEventListenerNotify instead of NULL 
	}
	else if ([aNotification object] == gainSlider) {
		AudioUnitEvent event;
		event.mArgument.mParameter = mParameter[kZirkOSC_Gain];
		event.mEventType = kAudioUnitEvent_BeginParameterChangeGesture;
		
		AUEventListenerNotify (NULL, self, &event);		// NOTE, if you have an AUEventListenerRef because you are listening to event notification, 
		// pass that as the first argument to AUEventListenerNotify instead of NULL 
	}
}

-(void)handleMouseUp: (NSNotification *) aNotification {
	if ([aNotification object] == azimSlider) {
		AudioUnitEvent event;
		event.mArgument.mParameter = mParameter[kZirkOSC_Azim];
		event.mEventType = kAudioUnitEvent_EndParameterChangeGesture;
		
		AUEventListenerNotify (NULL, self, &event);		// NOTE, if you have an AUEventListenerRef because you are listening to event notification, 
		// pass that as the first argument to AUEventListenerNotify instead of NULL 
	}
	else if ([aNotification object] == elevSlider) {
		AudioUnitEvent event;
		event.mArgument.mParameter = mParameter[kZirkOSC_Elev];
		event.mEventType = kAudioUnitEvent_EndParameterChangeGesture;
		
		AUEventListenerNotify (NULL, self, &event);		// NOTE, if you have an AUEventListenerRef because you are listening to event notification, 
		// pass that as the first argument to AUEventListenerNotify instead of NULL 
	}
	else if ([aNotification object] == azimDeltaSlider) {
		AudioUnitEvent event;
		event.mArgument.mParameter = mParameter[kZirkOSC_AzimDelta];
		event.mEventType = kAudioUnitEvent_EndParameterChangeGesture;
		
		AUEventListenerNotify (NULL, self, &event);		// NOTE, if you have an AUEventListenerRef because you are listening to event notification, 
		// pass that as the first argument to AUEventListenerNotify instead of NULL 
	}
	else if ([aNotification object] == elevDeltaSlider) {
		AudioUnitEvent event;
		event.mArgument.mParameter = mParameter[kZirkOSC_ElevDelta];
		event.mEventType = kAudioUnitEvent_EndParameterChangeGesture;
		
		AUEventListenerNotify (NULL, self, &event);		// NOTE, if you have an AUEventListenerRef because you are listening to event notification, 
		// pass that as the first argument to AUEventListenerNotify instead of NULL 
	}
	else if ([aNotification object] == azimSpanSlider) {
		AudioUnitEvent event;
		event.mArgument.mParameter = mParameter[kZirkOSC_AzimSpan];
		event.mEventType = kAudioUnitEvent_EndParameterChangeGesture;
		
		AUEventListenerNotify (NULL, self, &event);		// NOTE, if you have an AUEventListenerRef because you are listening to event notification, 
		// pass that as the first argument to AUEventListenerNotify instead of NULL 
	}
	else if ([aNotification object] == elevSpanSlider) {
		AudioUnitEvent event;
		event.mArgument.mParameter = mParameter[kZirkOSC_ElevSpan];
		event.mEventType = kAudioUnitEvent_EndParameterChangeGesture;
		
		AUEventListenerNotify (NULL, self, &event);		// NOTE, if you have an AUEventListenerRef because you are listening to event notification, 
		// pass that as the first argument to AUEventListenerNotify instead of NULL 
	}
	else if ([aNotification object] == gainSlider) {
		AudioUnitEvent event;
		event.mArgument.mParameter = mParameter[kZirkOSC_Gain];
		event.mEventType = kAudioUnitEvent_EndParameterChangeGesture;
		
		AUEventListenerNotify (NULL, self, &event);		// NOTE, if you have an AUEventListenerRef because you are listening to event notification, 
		// pass that as the first argument to AUEventListenerNotify instead of NULL 
	}
}

#pragma mark - Private Functions

void addParamListener (AUEventListenerRef listener, void* refCon, AudioUnitEvent *inEvent)
{
	inEvent->mEventType = kAudioUnitEvent_BeginParameterChangeGesture;
	verify_noerr ( AUEventListenerAddEventType(	listener, refCon, inEvent));
	
	inEvent->mEventType = kAudioUnitEvent_EndParameterChangeGesture;
	verify_noerr ( AUEventListenerAddEventType(	listener, refCon, inEvent));
	
	inEvent->mEventType = kAudioUnitEvent_ParameterValueChange;
	verify_noerr ( AUEventListenerAddEventType(	listener, refCon, inEvent));	
}

- (void)priv_addListeners
{
	NSAssert (	AUListenerCreate(	ParameterListenerDispatcher, self, 
                                    CFRunLoopGetCurrent(), kCFRunLoopDefaultMode, 0.100, // 100 ms
                                    &mParameterListener	) == noErr,
                @"[ZirkOSCCocoaView priv_addListeners] AUListenerCreate()");
	
    int i;
    for (i = 0; i < kNumberOfParameters; ++i) {
        mParameter[i].mAudioUnit = mAU;
        NSAssert (	AUListenerAddParameter (mParameterListener, NULL, &mParameter[i]) == noErr,
                    @"[ZirkOSCCocoaView priv_addListeners] AUListenerAddParameter()");
    }
    
    
	verify_noerr( AUEventListenerCreate(EventListenerDispatcher, self,
										CFRunLoopGetCurrent(), kCFRunLoopDefaultMode, 0.01, 0.1, 
										&mEventListener));
	
	AudioUnitEvent auEvent;
	AudioUnitParameter parameter = {mAU, kZirkOSC_Azim, kAudioUnitScope_Global, 0 };
	auEvent.mArgument.mParameter = parameter;
	
	for (int i = 0; i < kNumberOfParameters; i++)
	{
		auEvent.mArgument.mParameter.mParameterID = (AudioUnitParameterID)i;
		addParamListener (mEventListener, self, &auEvent);
	}
    
   	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleMouseDown:) name:ZirkOSCAU_GestureSliderMouseDownNotification object:azimSlider];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleMouseDown:) name:ZirkOSCAU_GestureSliderMouseDownNotification object:azimDeltaSlider];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleMouseDown:) name:ZirkOSCAU_GestureSliderMouseDownNotification object:azimSpanSlider];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleMouseDown:) name:ZirkOSCAU_GestureSliderMouseDownNotification object:elevSlider];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleMouseDown:) name:ZirkOSCAU_GestureSliderMouseDownNotification object:elevDeltaSlider];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleMouseDown:) name:ZirkOSCAU_GestureSliderMouseDownNotification object:elevSpanSlider];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleMouseDown:) name:ZirkOSCAU_GestureSliderMouseDownNotification object:gainSlider];
	
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleMouseUp:) name:ZirkOSCAU_GestureSliderMouseUpNotification object:azimSlider];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleMouseUp:) name:ZirkOSCAU_GestureSliderMouseUpNotification object:azimDeltaSlider];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleMouseUp:) name:ZirkOSCAU_GestureSliderMouseUpNotification object:azimSpanSlider];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleMouseUp:) name:ZirkOSCAU_GestureSliderMouseUpNotification object:elevSlider];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleMouseUp:) name:ZirkOSCAU_GestureSliderMouseUpNotification object:elevDeltaSlider];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleMouseUp:) name:ZirkOSCAU_GestureSliderMouseUpNotification object:elevSpanSlider];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleMouseUp:) name:ZirkOSCAU_GestureSliderMouseUpNotification object:gainSlider];
}

void removeParamListener (AUEventListenerRef listener, void* refCon, AudioUnitEvent *inEvent)
{
	inEvent->mEventType = kAudioUnitEvent_BeginParameterChangeGesture;
	verify_noerr ( AUEventListenerRemoveEventType(	listener, refCon, inEvent));
	
	inEvent->mEventType = kAudioUnitEvent_EndParameterChangeGesture;
	verify_noerr ( AUEventListenerRemoveEventType(	listener, refCon, inEvent));
	
	inEvent->mEventType = kAudioUnitEvent_ParameterValueChange;
	verify_noerr ( AUEventListenerRemoveEventType(	listener, refCon, inEvent));	
}

- (void)priv_removeListeners
{
    int i;
    for (i = 0; i < kNumberOfParameters; ++i) {
        NSAssert (	AUListenerRemoveParameter(mParameterListener, NULL, &mParameter[i]) == noErr,
                    @"[ZirkOSCCocoaView priv_removeListeners] AUListenerRemoveParameter()");
    }
    
	NSAssert (	AUListenerDispose(mParameterListener) == noErr,
                @"[ZirkOSCCocoaView priv_removeListeners] AUListenerDispose()");
    
    AudioUnitEvent auEvent;
	AudioUnitParameter parameter = {mAU, kZirkOSC_Azim, kAudioUnitScope_Global, 0 };
	auEvent.mArgument.mParameter = parameter;
    
	for (int i = 0; i < kNumberOfParameters; i++)
	{
		auEvent.mArgument.mParameter.mParameterID = (AudioUnitParameterID)i;
		removeParamListener (mEventListener, self, &auEvent);
	}
    
    NSAssert (	AUListenerDispose(mEventListener) == noErr,
              @"[ZirkOSCCocoaView priv_removeListeners] AUListenerDispose()");
                
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)priv_synchronizeUIWithParameterValues
{
	Float32 value;
    int i;
    
    for (i = 0; i < kNumberOfParameters; ++i) {
        // only has global parameters
        NSAssert (	AudioUnitGetParameter(mAU, mParameter[i].mParameterID, kAudioUnitScope_Global, 0, &value) == noErr,
                  @"[ZirkOSCCocoaView synchronizeUIWithParameterValues] (x.1)");
        NSAssert (	AUParameterSet (mParameterListener, self, &mParameter[i], value, 0) == noErr,
                    @"[ZirkOSCCocoaView synchronizeUIWithParameterValues] (x.2)");
        NSAssert (	AUParameterListenerNotify (mParameterListener, self, &mParameter[i]) == noErr,
                    @"[ZirkOSCCocoaView synchronizeUIWithParameterValues] (x.3)");
    }
}

#pragma mark - Listener Callback Dispatchee

- (void)priv_parameterListener:(void *)inObject parameter:(const AudioUnitParameter *)inParameter value:(Float32)inValue
{
	switch (inParameter->mParameterID) {
		case kZirkOSC_Azim:
			[azimSlider setFloatValue:inValue];
			[azimField setStringValue:[[NSNumber numberWithFloat:inValue] stringValue]];
			break;
		case kZirkOSC_Elev:
			[elevSlider setFloatValue:inValue];
			[elevField setStringValue:[[NSNumber numberWithFloat:inValue] stringValue]];
			break;
		case kZirkOSC_AzimDelta:
			[azimDeltaSlider setFloatValue:inValue];
			[azimDeltaField setStringValue:[[NSNumber numberWithFloat:inValue] stringValue]];
			break;
		case kZirkOSC_ElevDelta:
			[elevDeltaSlider setFloatValue:inValue];
			[elevDeltaField setStringValue:[[NSNumber numberWithFloat:inValue] stringValue]];
			break;
		case kZirkOSC_AzimSpan:
			[azimSpanSlider setFloatValue:inValue];
			[azimSpanField setStringValue:[[NSNumber numberWithFloat:inValue] stringValue]];
			break;
		case kZirkOSC_ElevSpan:
			[elevSpanSlider setFloatValue:inValue];
			[elevSpanField setStringValue:[[NSNumber numberWithFloat:inValue] stringValue]];
			break;
		case kZirkOSC_Gain:
			[gainSlider setFloatValue:inValue];
			[gainField setStringValue:[[NSNumber numberWithFloat:inValue] stringValue]];
			break;
	}
}

- (void)priv_eventListener:(void *) inObject event:(const AudioUnitEvent *)inEvent value:(Float32)inValue
{
    //Float32 azim, elev, dist, distMult;
	switch (inEvent->mEventType)
    {
		case kAudioUnitEvent_ParameterValueChange:
            //AudioUnitGetParameter([self getAU], kZirkOSC_Azim, kAudioUnitScope_Global, 0, &azim);
            //AudioUnitGetParameter([self getAU], kZirkOSC_Elev, kAudioUnitScope_Global, 0, &elev);
            //AudioUnitGetParameter([self getAU], kZirkOSC_Dist, kAudioUnitScope_Global, 0, &dist);
           // AudioUnitGetParameter([self getAU], kZirkOSC_DistMult, kAudioUnitScope_Global, 0, &distMult);
			switch (inEvent->mArgument.mParameter.mParameterID) {
                case kZirkOSC_Azim:
                    [azimSlider setFloatValue: inValue];
                    [azimField  setFloatValue: inValue];
                    [domeView setAzimuth: inValue];
					[domeView setNeedsDisplay:YES];
                    break;
					
                case kZirkOSC_Elev:
                    [elevSlider setFloatValue: inValue];
                    [elevField setFloatValue: inValue];
                    [domeView setZenith: inValue];
					[domeView setNeedsDisplay:YES];
                    break;
					
				 case kZirkOSC_AzimDelta:
                    [azimDeltaSlider setFloatValue: inValue];
                    [azimDeltaField  setFloatValue: inValue];
                    [domeView setAzimuthDelta: inValue];
					[domeView setNeedsDisplay:YES];
                    break;
					
                case kZirkOSC_ElevDelta:
                    [elevDeltaSlider setFloatValue: inValue];
                    [elevDeltaField setFloatValue: inValue];
                    [domeView setZenithDelta: inValue];
					[domeView setNeedsDisplay:YES];
                    break;
					
                case kZirkOSC_AzimSpan:
                    [azimSpanSlider setFloatValue: inValue];
                    [azimSpanField  setFloatValue: inValue];
                    [domeView setAzimuthSpan: inValue];
					[domeView setNeedsDisplay:YES];
                    break;
					
                case kZirkOSC_ElevSpan:
                    [elevSpanSlider setFloatValue: inValue];
                    [elevSpanField setFloatValue: inValue];
                    [domeView setZenithSpan: inValue];
					[domeView setNeedsDisplay:YES];
                    break;
				
				case kZirkOSC_Gain:
                    [gainSlider setFloatValue: inValue];
                    [gainField setFloatValue: inValue];
                    break;
            }
			break;
		case kAudioUnitEvent_BeginParameterChangeGesture:
			[domeView handleBeginGesture];
			break;
		case kAudioUnitEvent_EndParameterChangeGesture:
			[domeView handleEndGesture];
			break;
	}
}

@end
