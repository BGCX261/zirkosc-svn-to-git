
#import <Cocoa/Cocoa.h>
#import <AudioUnit/AudioUnit.h>
#import <AudioToolbox/AudioToolbox.h>

#import "DomeView.h"
#import "ZirkConstants.h"

/************************************************************************************************************/
/* NOTE: It is important to rename ALL ui classes when using the XCode Audio Unit with Cocoa View template	*/
/*		 Cocoa has a flat namespace, and if you use the default filenames, it is possible that you will		*/
/*		 get a namespace collision with classes from the cocoa view of a previously loaded audio unit.		*/
/*		 We recommend that you use a unique prefix that includes the manufacturer name and unit name on		*/
/*		 all objective-C source files. You may use an underscore in your name, but please refrain from		*/
/*		 starting your class name with an undescore as these names are reserved for Apple.					*/
/*  Example  : AppleDemoFilter_UIView AppleDemoFilter_ViewFactory											*/
/************************************************************************************************************/

extern NSString *kDomeViewDataChangedNotification;
extern NSString *kDomeViewBeginGestureNotification;
extern NSString *kDomeViewEndGestureNotification;

@interface ZirkOSCAU_GestureSlider : NSSlider
{
	float mThickness;
}
@end

@interface ZirkOSCCocoaView : NSView
{
@private
    // IB Members
	IBOutlet DomeView *domeView;

	IBOutlet NSTextField           *channelField;
	IBOutlet NSTextField           *channelCountField;
	IBOutlet NSTextField           *oscPortField;
	IBOutlet NSButton			   *activeButton;

    IBOutlet NSTextField           *azimField;
    IBOutlet ZirkOSCAU_GestureSlider *azimSlider;
	
	IBOutlet NSTextField           *azimDeltaField;
    IBOutlet ZirkOSCAU_GestureSlider *azimDeltaSlider;
	
	IBOutlet NSTextField           *azimSpanField;
    IBOutlet ZirkOSCAU_GestureSlider *azimSpanSlider;
    
    IBOutlet NSTextField           *elevField;
    IBOutlet ZirkOSCAU_GestureSlider *elevSlider;
    
	IBOutlet NSTextField           *elevDeltaField;
    IBOutlet ZirkOSCAU_GestureSlider *elevDeltaSlider;
	
    IBOutlet NSTextField           *elevSpanField;
    IBOutlet ZirkOSCAU_GestureSlider *elevSpanSlider;
	
	IBOutlet NSTextField           *gainField;
    IBOutlet ZirkOSCAU_GestureSlider *gainSlider;
    
    // Other Members
    AudioUnit 				mAU;
	AudioUnitParameter		mParameter[kNumberOfParameters];
    AUParameterListenerRef	mParameterListener;
	AUEventListenerRef		mEventListener;
}

#pragma mark ____ PUBLIC FUNCTIONS ____
- (void)setAU:(AudioUnit)inAU;
- (AudioUnit)getAU;

#pragma mark ____ INTERFACE ACTIONS ____
- (IBAction)azimChanged:(id)sender;
- (IBAction)elevChanged:(id)sender;
- (IBAction)azimDeltaChanged:(id)sender;
- (IBAction)elevDeltaChanged:(id)sender;
- (IBAction)azimSpanChanged:(id)sender;
- (IBAction)elevSpanChanged:(id)sender;
- (IBAction)gainChanged:(id)sender;
- (IBAction)activeChanged:(id)sender;

#pragma mark ____ PRIVATE FUNCTIONS
- (void)priv_synchronizeUIWithParameterValues;
- (void)priv_addListeners;
- (void)priv_removeListeners;

#pragma mark ____ LISTENER CALLBACK DISPATCHEE ____
- (void)priv_parameterListener:(void *)inObject parameter:(const AudioUnitParameter *)inParameter value:(Float32)inValue;
- (void)priv_eventListener:(void *) inObject event:(const AudioUnitEvent *)inEvent value:(Float32)inValue;

@end
