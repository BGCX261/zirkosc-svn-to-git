

#include "ZirkOSC.h"


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
COMPONENT_ENTRY(ZirkOSCAU)

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
static AUChannelInfo * GetChannelInfo()
{
	static AUChannelInfo info[kMaxNumberOfChannels];
	static bool inited = false;
	if (!inited)
	{
		for (int i = 0; i < kMaxNumberOfChannels; i++)
		{
			info[i].inChannels = i + 1;
			info[i].outChannels = i + 1;
		}
		inited = true;
	}
	return info;
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	ZirkOSCAU::ZirkOSCAU
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

ZirkOSCAU::ZirkOSCAU(AudioUnit component)
	: AUEffectBase(component)
{
    // only need to do this once (not with every new AU instance).
    // TODO: move this elsewhere
	
	mChannel = 0;
	mChannelCount = 1;
	mOscPort = 18032;
	mActive = 1;
	
	char port[32];
	snprintf(port, sizeof(port), "%d", mOscPort);
	mOsc = lo_address_new("127.0.0.1", port);
	
	CreateElements();
    
    Globals()->UseIndexedParameters(kNumberOfParameters);
    
	AUEffectBase::SetParameter(kZirkOSC_Azim, kZirkOSC_Azim_Def );
	AUEffectBase::SetParameter(kZirkOSC_Elev, kZirkOSC_Elev_Def );
	AUEffectBase::SetParameter(kZirkOSC_AzimDelta, kZirkOSC_AzimDelta_Def );
	AUEffectBase::SetParameter(kZirkOSC_ElevDelta, kZirkOSC_ElevDelta_Def );
	AUEffectBase::SetParameter(kZirkOSC_AzimSpan, kZirkOSC_AzimSpan_Def );
	AUEffectBase::SetParameter(kZirkOSC_ElevSpan, kZirkOSC_ElevSpan_Def );
	AUEffectBase::SetParameter(kZirkOSC_Gain, kZirkOSC_Gain_Def );
        
#if AU_DEBUG_DISPATCHER
	mDebugDispatcher = new AUDebugDispatcher (this);
#endif	
}


ZirkOSCAU::~ZirkOSCAU()
{
	lo_address_free(mOsc);

#if AU_DEBUG_DISPATCHER
	delete mDebugDispatcher;
#endif
}

//_____________________________________________________________________________
//
UInt32 ZirkOSCAU::SupportedNumChannels (	const AUChannelInfo** 			outInfo)
{
	if (outInfo) *outInfo = GetChannelInfo();
	return kMaxNumberOfChannels;
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	ZirkOSCAU::GetParameterValueStrings
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
OSStatus			ZirkOSCAU::GetParameterValueStrings(AudioUnitScope		inScope,
                                                                AudioUnitParameterID	inParameterID,
                                                                CFArrayRef *		outStrings)
{
    return kAudioUnitErr_InvalidProperty;
}


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	ZirkOSCAU::GetParameterInfo
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
OSStatus			ZirkOSCAU::GetParameterInfo(AudioUnitScope		inScope,
                                                        AudioUnitParameterID	inParameterID,
                                                        AudioUnitParameterInfo	&outParameterInfo )
{
	OSStatus result = noErr;

	outParameterInfo.flags = 	kAudioUnitParameterFlag_IsWritable
						|		kAudioUnitParameterFlag_IsReadable;
    
    if (inScope == kAudioUnitScope_Global) {
        switch(inParameterID)
        {
            case kZirkOSC_Azim:
                AUBase::FillInParameterName (outParameterInfo, kZirkOSC_Azim_Name, false);
                outParameterInfo.unit = kAudioUnitParameterUnit_Degrees;
                outParameterInfo.minValue = kZirkOSC_Azim_Min;
                outParameterInfo.maxValue = kZirkOSC_Azim_Max;
                outParameterInfo.defaultValue = kZirkOSC_Azim_Def;
                break;
            case kZirkOSC_Elev:
                AUBase::FillInParameterName (outParameterInfo, kZirkOSC_Elev_Name, false);
                outParameterInfo.unit = kAudioUnitParameterUnit_Degrees;
                outParameterInfo.minValue = kZirkOSC_Elev_Min;
                outParameterInfo.maxValue = kZirkOSC_Elev_Max;
                outParameterInfo.defaultValue = kZirkOSC_Elev_Def;
                break;
			case kZirkOSC_AzimDelta:
                AUBase::FillInParameterName (outParameterInfo, kZirkOSC_AzimDelta_Name, false);
                outParameterInfo.unit = kAudioUnitParameterUnit_Degrees;
                outParameterInfo.minValue = kZirkOSC_AzimDelta_Min;
                outParameterInfo.maxValue = kZirkOSC_AzimDelta_Max;
                outParameterInfo.defaultValue = kZirkOSC_AzimDelta_Def;
                break;
            case kZirkOSC_ElevDelta:
                AUBase::FillInParameterName (outParameterInfo, kZirkOSC_ElevDelta_Name, false);
                outParameterInfo.unit = kAudioUnitParameterUnit_Degrees;
                outParameterInfo.minValue = kZirkOSC_ElevDelta_Min;
                outParameterInfo.maxValue = kZirkOSC_ElevDelta_Max;
                outParameterInfo.defaultValue = kZirkOSC_ElevDelta_Def;
                break;
            case kZirkOSC_AzimSpan:
                AUBase::FillInParameterName (outParameterInfo, kZirkOSC_AzimSpan_Name, false);
                outParameterInfo.unit = kAudioUnitParameterUnit_Degrees;
                outParameterInfo.minValue = kZirkOSC_AzimSpan_Min;
                outParameterInfo.maxValue = kZirkOSC_AzimSpan_Max;
                outParameterInfo.defaultValue = kZirkOSC_AzimSpan_Def;
                break;
            case kZirkOSC_ElevSpan:
                AUBase::FillInParameterName (outParameterInfo, kZirkOSC_ElevSpan_Name, false);
                outParameterInfo.unit = kAudioUnitParameterUnit_Degrees;
                outParameterInfo.minValue = kZirkOSC_ElevSpan_Min;
                outParameterInfo.maxValue = kZirkOSC_ElevSpan_Max;
                outParameterInfo.defaultValue = kZirkOSC_ElevSpan_Def;
                break;
			case kZirkOSC_Gain:
                AUBase::FillInParameterName (outParameterInfo, kZirkOSC_Gain_Name, false);
                outParameterInfo.unit = kAudioUnitParameterUnit_LinearGain;
                outParameterInfo.minValue = kZirkOSC_Gain_Min;
                outParameterInfo.maxValue = kZirkOSC_Gain_Max;
                outParameterInfo.defaultValue = kZirkOSC_Gain_Def;
                break;
			default:
                result = kAudioUnitErr_InvalidParameter;
                break;
            }
	} else {
        result = kAudioUnitErr_InvalidParameter;
    }
    


	return result;
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	ZirkOSCAU::GetPropertyInfo
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
OSStatus			ZirkOSCAU::GetPropertyInfo (AudioUnitPropertyID	inID,
                                                        AudioUnitScope		inScope,
                                                        AudioUnitElement	inElement,
                                                        UInt32 &		outDataSize,
                                                        Boolean &		outWritable)
{
	if (inScope == kAudioUnitScope_Global) 
	{
		switch (inID) 
		{
			case kAudioUnitProperty_CocoaUI:
				outWritable = false;
				outDataSize = sizeof (AudioUnitCocoaViewInfo);
				return noErr;
				
			case kChannelId:
			case kChannelCountId:
			case kOscPortId:
			case kOscActiveId:
				outWritable = true;
				outDataSize = sizeof(uint32_t);
				return noErr;
					
		}
	}

	return AUEffectBase::GetPropertyInfo (inID, inScope, inElement, outDataSize, outWritable);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	ZirkOSCAU::GetProperty
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
OSStatus			ZirkOSCAU::GetProperty(	AudioUnitPropertyID inID,
															AudioUnitScope 		inScope,
															AudioUnitElement 	inElement,
															void *				outData )
{
	if (inScope == kAudioUnitScope_Global) 
	{
		switch (inID) 
		{
			case kAudioUnitProperty_CocoaUI:
			{
				// Look for a resource in the main bundle by name and type.
				CFBundleRef bundle = CFBundleGetBundleWithIdentifier( CFSTR("com.audiounit.ZirkOSCAU") );
				
				if (bundle == NULL) return fnfErr;
                
				CFURLRef bundleURL = CFBundleCopyResourceURL( bundle, 
                    CFSTR("ZirkOSCCocoaViewFactory"), 
                    CFSTR("bundle"), 
                    NULL);
                
                if (bundleURL == NULL) return fnfErr;

				AudioUnitCocoaViewInfo cocoaInfo;
				cocoaInfo.mCocoaAUViewBundleLocation = bundleURL;
				cocoaInfo.mCocoaAUViewClass[0] = CFStringCreateWithCString(NULL, "ZirkOSCCocoaViewFactory", kCFStringEncodingUTF8);
				
				*((AudioUnitCocoaViewInfo *)outData) = cocoaInfo;
				
				return noErr;
			}
			
			case kChannelId:
				*(uint32_t*)outData = mChannel;
				return noErr;
				
			case kChannelCountId:
				*(uint32_t*)outData = mChannelCount;
				return noErr;
				
			case kOscPortId:
				*(uint32_t*)outData = mOscPort;
				return noErr;
				
			case kOscActiveId:
				*(uint32_t*)outData = mActive;
				return noErr;
		}
	}


	return AUEffectBase::GetProperty (inID, inScope, inElement, outData);
}


void ZirkOSCAU::updateOscPort()
{
	// mOsc should always be either NULL or valid
	// so set it to NULL before freeing it
				
	lo_address osc = mOsc;
	mOsc = NULL;
	lo_address_free(osc);
	
	char port[32];
	snprintf(port, sizeof(port), "%d", mOscPort);
	mOsc = lo_address_new("127.0.0.1", port);
}


OSStatus			ZirkOSCAU::SetProperty(AudioUnitPropertyID inID,
									   AudioUnitScope 		inScope,
									   AudioUnitElement 	inElement,
									   const void *			inData,
									   UInt32 				inDataSize)
{
	//printf("SetProperty scope: %d inID: %d\n", inScope, inID);

	if (inScope == kAudioUnitScope_Global) 
	{
		switch (inID) 
		{
			case kChannelId:
			{
				if (inDataSize != sizeof(uint32_t))
					return paramErr;
					
				mChannel = *(uint32_t*)inData;
				return noErr;
			}
			
			case kChannelCountId:
			{
				if (inDataSize != sizeof(uint32_t))
					return paramErr;
					
				mChannelCount = *(uint32_t*)inData;
				return noErr;
			}
				
			case kOscPortId:
			{
				if (inDataSize != sizeof(uint32_t))
					return paramErr;
				
				mOscPort = *(uint32_t*)inData;
				updateOscPort();
			
				return noErr;
			}
			
			case kOscActiveId:
			{
				if (inDataSize != sizeof(uint32_t))
					return paramErr;
				
				mActive = *(uint32_t*)inData;
				return noErr;
			}
		}
	}

	return AUEffectBase::SetProperty (inID, inScope, inElement, inData, inDataSize);
}

OSStatus ZirkOSCAU::SetParameter(AudioUnitParameterID inID,
												AudioUnitScope inScope,
												AudioUnitElement inElement,
												AudioUnitParameterValue inValue,
												UInt32 inBufferOffsetInFrames)
{
	//fprintf(stderr, "SetParameter id: %i value: %f offset: %i\n", inID, inValue, inBufferOffsetInFrames);
	
	OSStatus result = AUBase::SetParameter(inID, inScope, inElement, inValue, inBufferOffsetInFrames);
	if ((result != noErr) || (inScope != kAudioUnitScope_Global)) return result;
	
	if ((int)inID < 0 || (int)inID >= kNumberOfParameters)
		return kAudioUnitErr_InvalidParameter;
		
	float azim = GetParameter(kZirkOSC_Azim) / 180.;
	float elev = GetParameter(kZirkOSC_Elev) / 180.;
	float azimdelta = GetParameter(kZirkOSC_AzimDelta) / 180.;
	float elevdelta = GetParameter(kZirkOSC_ElevDelta) / 180.;
	float azimspan = GetParameter(kZirkOSC_AzimSpan) / 180.;
	float elevspan = GetParameter(kZirkOSC_ElevSpan) / 180.;
	float gain = GetParameter(kZirkOSC_Gain);
		
	lo_address osc = mOsc;
	//bool isBypassed = IsBypassEffect();
	//SInt16 auNumInputs = (SInt16) GetInput(0)->GetStreamFormat().mChannelsPerFrame;
	//SInt16 auNumOutputs = (SInt16) GetOutput(0)->GetStreamFormat().mChannelsPerFrame;
	//fprintf(stderr, "bypassed: %d inputs: %d output: %d hasInput: %d\n", isBypassed, auNumInputs, auNumOutputs, HasInput(0));
	//if (osc && !isBypassed)
	if (osc && mActive)
	{
		int ch = mChannel;
		int end = ch + mChannelCount;
	
		for ( ; ch < end ; ch++ )
		{
			lo_send(osc, "/pan/az", "ifffff", ch, azim, elev, azimspan, elevspan, gain);
			azim += azimdelta;
			elev += elevdelta;
		}
	}	
	return noErr;
}

//------------------------------------------------------------------------------------------
static void AddNumToDictionary (CFMutableDictionaryRef dict, CFStringRef key, SInt32 value)
{
	CFNumberRef num = CFNumberCreate (NULL, kCFNumberSInt32Type, &value);
	CFDictionarySetValue (dict, key, num);
	CFRelease (num);
}
OSStatus ZirkOSCAU::SaveState( CFPropertyListRef * outData)
{
	fprintf(stderr, "SaveState\n");

	ComponentResult result = AUBase::SaveState(outData);
	if (result != noErr)
		return result;

	CFMutableDictionaryRef dict = (CFMutableDictionaryRef) *outData; // AUBAse made a mutable dict

	AddNumToDictionary(dict, CFSTR("zirk_oscport"), mOscPort);
	AddNumToDictionary(dict, CFSTR("zirk_channel"), mChannel);
	AddNumToDictionary(dict, CFSTR("zirk_channel_count"), mChannelCount);
	AddNumToDictionary(dict, CFSTR("zirk_active"), mActive);
	
	return noErr;
}

//------------------------------------------------------------------------------------------
OSStatus ZirkOSCAU::RestoreState( CFPropertyListRef	inData)
{
	fprintf(stderr, "RestoreState\n");

	ComponentResult result = AUBase::RestoreState(inData);
	if (result != noErr)
		return result;

	CFDictionaryRef dict = static_cast<CFDictionaryRef>(inData);
	{
		CFNumberRef cfnum = reinterpret_cast<CFNumberRef>(CFDictionaryGetValue (dict, CFSTR("zirk_oscport")));
		if (cfnum)
		{
			SInt32 value;
			CFNumberGetValue (cfnum, kCFNumberSInt32Type, &value);
			mOscPort = value;
			updateOscPort();
		}
	}
	{
		CFNumberRef cfnum = reinterpret_cast<CFNumberRef>(CFDictionaryGetValue (dict, CFSTR("zirk_channel")));
		if (cfnum)
		{
			SInt32 value;
			CFNumberGetValue (cfnum, kCFNumberSInt32Type, &value);
			mChannel = value;
		}
	}
	{
		CFNumberRef cfnum = reinterpret_cast<CFNumberRef>(CFDictionaryGetValue (dict, CFSTR("zirk_channel_count")));
		if (cfnum)
		{
			SInt32 value;
			CFNumberGetValue (cfnum, kCFNumberSInt32Type, &value);
			mChannelCount = value;
		}
	}
	{
		CFNumberRef cfnum = reinterpret_cast<CFNumberRef>(CFDictionaryGetValue (dict, CFSTR("zirk_active")));
		if (cfnum)
		{
			SInt32 value;
			CFNumberGetValue (cfnum, kCFNumberSInt32Type, &value);
			mActive = value;
		}
	}

	return noErr;
}



#pragma mark ____ZirkOSCAUEffectKernel


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	ZirkOSCAU::ZirkOSCAU
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
ZirkOSCAU::ZirkOSCAUKernel::ZirkOSCAUKernel(AUEffectBase *inAudioUnit )
: AUKernelBase(inAudioUnit)
{
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	ZirkOSCAU::ZirkOSCAUKernel::Reset()
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
void		ZirkOSCAU::ZirkOSCAUKernel::Reset()
{
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	ZirkOSCAU::ZirkOSCAUKernel::Process
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
void		ZirkOSCAU::ZirkOSCAUKernel::Process(	const Float32 	*inSourceP,
                                                    Float32		 	*inDestP,
                                                    UInt32 			inFramesToProcess,
                                                    UInt32			inNumChannels, // for version 2 AudioUnits inNumChannels is always 1
                                                    bool			&ioSilence )
{

	if (inSourceP == inDestP)
		return;
				
				
	//This code will pass-thru the audio data.
	//This is where you want to process data to produce an effect.

	UInt32 nSampleFrames = inFramesToProcess;
	const Float32 *sourceP = inSourceP;
	Float32 *destP = inDestP;
	
	while (nSampleFrames-- > 0) {
		Float32 inputSample = *sourceP;
		
		//The current (version 2) AudioUnit specification *requires* 
	    //non-interleaved format for all inputs and outputs. Therefore inNumChannels is always 1
		
		sourceP += inNumChannels;	// advance to next frame (e.g. if stereo, we're advancing 2 samples);
									// we're only processing one of an arbitrary number of interleaved channels

        // here's where you do your DSP work
        Float32 outputSample = inputSample;
		
		*destP = outputSample;
		destP += inNumChannels;
	}
}
