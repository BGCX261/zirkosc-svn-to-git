#import <Cocoa/Cocoa.h>
#import "ZirkOSC.h"

/**
 * @brief Provides a top-down view of dome spacialization
 *
 * This class provides a simplified view of the detailed OpenGL view of
 * Zirkonium's speaker dome. It serves primarily to represent the area from
 * which sounds originate. Unlike Zirkonium's detailed view, the Zirkalloy view
 * does not indicate the location of the speakers but only of the source
 * direction.
 */
@interface DomeView : NSView
{	
	NSRect	mDomeFrame, mFullFrame;
	float	mActiveWidth;
	BOOL	mMouseDown;
    
    // Attribute copies
    NSPoint     mSourcePoint;
    PolarAngles mSourceHeading;
    NSPoint     mShapeSize;
	
	int mChannelCount;
	float mAzimuthDelta;
	float mZenithDelta;
	
	NSImage   * mBackgroundCache;
    
    // Math
    float   mRadius;
    NSPoint mCentre;
}

-(void)setChannelCount:(int)count;
-(int)channelCount;

-(void)setSourcePoint:(NSPoint)pos;
-(NSPoint)sourcePoint;

-(void)setHeading:(PolarAngles)heading;
-(PolarAngles)heading;

-(void)setAzimuth:(float)azimuth;
-(float)azimuth;

-(void)setZenith:(float)zenith;
-(float)zenith;

-(void)setAzimuthDelta:(float)azimuthDelta;
-(float)azimuthDelta;

-(void)setZenithDelta:(float)zenithDelta;
-(float)zenithDelta;

-(void)setAzimuthSpan:(float)azimuthSpan;
-(float)azimuthSpan;

-(void)setZenithSpan:(float)zenithSpan;
-(float)zenithSpan;

-(void) handleBeginGesture;
-(void) handleEndGesture;

@end
