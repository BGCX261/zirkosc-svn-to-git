//
//  ZirkConstants.h
//  ZirkOSC
//
//  Created by makira on 2012-03-02.
//  Copyright 2012 _The_Company_. All rights reserved.
//

#ifndef __ZirkConstants_h__
#define __ZirkConstants_h__

static const AudioUnitParameterID kZirkOSC_Azim = 0;
static const AudioUnitParameterID kZirkOSC_Elev = 1;
static const AudioUnitParameterID kZirkOSC_AzimSpan = 2;
static const AudioUnitParameterID kZirkOSC_ElevSpan = 3;
static const AudioUnitParameterID kZirkOSC_AzimDelta = 4;
static const AudioUnitParameterID kZirkOSC_ElevDelta = 5;
static const AudioUnitParameterID kZirkOSC_Gain = 6;
static const int kNumberOfParameters = 7;

static const int kMaxNumberOfChannels = 64;

static const AudioUnitPropertyID kChannelId = 70000;
static const AudioUnitPropertyID kChannelCountId = 70001;
static const AudioUnitPropertyID kOscPortId = 70002;
static const AudioUnitPropertyID kOscActiveId = 70003;

const CFStringRef kZirkOSC_Azim_Name = CFSTR("Azimuth");
const AudioUnitParameterValue kZirkOSC_Azim_Min = -180.0f;
const AudioUnitParameterValue kZirkOSC_Azim_Max = 180.0f;
const AudioUnitParameterValue kZirkOSC_Azim_Def = 0.0f;

const CFStringRef kZirkOSC_Elev_Name = CFSTR("Elevation");
const AudioUnitParameterValue kZirkOSC_Elev_Min = 0.0f;
const AudioUnitParameterValue kZirkOSC_Elev_Max = 90.0f;
const AudioUnitParameterValue kZirkOSC_Elev_Def = 0.0f;

const CFStringRef kZirkOSC_AzimDelta_Name = CFSTR("Azimuth Delta");
const AudioUnitParameterValue kZirkOSC_AzimDelta_Min = 0.0f;
const AudioUnitParameterValue kZirkOSC_AzimDelta_Max = kZirkOSC_Azim_Max * 2.0;
const AudioUnitParameterValue kZirkOSC_AzimDelta_Def = 0.0f;
 
const CFStringRef kZirkOSC_ElevDelta_Name = CFSTR("Elevation Delta");
const AudioUnitParameterValue kZirkOSC_ElevDelta_Min = 0.0f;
const AudioUnitParameterValue kZirkOSC_ElevDelta_Max = 90.0f;
const AudioUnitParameterValue kZirkOSC_ElevDelta_Def = 0.0f;

const CFStringRef kZirkOSC_AzimSpan_Name = CFSTR("Azimuth Span");
const AudioUnitParameterValue kZirkOSC_AzimSpan_Min = 0.0f;
const AudioUnitParameterValue kZirkOSC_AzimSpan_Max = kZirkOSC_Azim_Max * 2.0;
const AudioUnitParameterValue kZirkOSC_AzimSpan_Def = 0.0f;
 
const CFStringRef kZirkOSC_ElevSpan_Name = CFSTR("Elevation Span");
const AudioUnitParameterValue kZirkOSC_ElevSpan_Min = 0.0f;
const AudioUnitParameterValue kZirkOSC_ElevSpan_Max = 90.0f;
const AudioUnitParameterValue kZirkOSC_ElevSpan_Def = 0.0f;

const CFStringRef kZirkOSC_Gain_Name = CFSTR("Gain");
const AudioUnitParameterValue kZirkOSC_Gain_Min = 0.0f;
const AudioUnitParameterValue kZirkOSC_Gain_Max = 1.0f;
const AudioUnitParameterValue kZirkOSC_Gain_Def = 1.0f;
 
#endif /* __ZirkConstants_h__ */
